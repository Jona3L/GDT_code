"""
Baseline agent implementation in CARLA 0.9.13
"""
